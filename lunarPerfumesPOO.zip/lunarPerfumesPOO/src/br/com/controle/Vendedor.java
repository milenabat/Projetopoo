/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

import java.util.ArrayList;


/**
 *
 * @author Samil
 */
public class Vendedor {
    private Double codigo;
    private String nome;
    private String email;

    public static ArrayList<Usuario> listarVendedor() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
        public Double getCodigo() {
            return codigo;
        }

        public void setCodigo(Double codigo) {
            this.codigo = codigo;
        }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
 
        private String senha;

public String getSenha() {
    return senha;
}

public void setSenha(String senha) {
    this.senha = senha;
}
}

